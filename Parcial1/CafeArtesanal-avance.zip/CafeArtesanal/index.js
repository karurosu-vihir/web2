import info from "./db.js"

const data = info()
const productos = data.producto

document.addEventListener("DOMContentLoaded",()=>{
    orgnizarproductos(window.location.pathname)
})

const orgnizarproductos = (pathname) => {
    switch (pathname) {
        case "/pages/Cafes.html":
            console.log(productos.filter(producto => producto.tipo === "cafe"))
            break;
        case "/pages/helado.html":
            console.log(productos.filter(producto => producto.tipo === "bebida helada"));
            break;
        case "/pages/postre.html":
            console.log(productos.filter(producto => producto.tipo === "postre"));
            break;
            case "/":
                console.log(productospopulares());
                break;
        default:
            break;
    }
} 

const productospopulares = () => {
   let poulares = [...productos].sort((a,b)=> b.comprados - a.comprados).slice(0,5);
   return poulares;
}


// Funciones click
const toggle_ham = ()=>{
    const ul = document.querySelector('nav ul');
    if(ul.className === "navbar-ham" ){
        ul.classList.remove('navbar-ham');
        ul.classList.add('navbar');
    }
    else{
    ul.classList.add('navbar-ham');
    ul.classList.remove('navbar');
    }
}

const toggle_dropdown = ()=>{
    const menu = document.querySelectorAll('.navbar-item a')[1];
    const ul = document.querySelector('.dropdown');
    if(ul.style.display  === "" ){
        ul.style.display = "block";
        menu.style.backgroundColor = "#591F0B";
        menu.style.color = "white";
    }
    else{
        const responsive = document.querySelector('nav ul');
        if(responsive.className !== "navbar-ham" ){
            menu.style.backgroundColor = "#9E7418";
            menu.style.color = "black";
        }
        ul.style.display = "";
    }
}

window.toggle_dropdown = toggle_dropdown
window.toggle_ham = toggle_ham